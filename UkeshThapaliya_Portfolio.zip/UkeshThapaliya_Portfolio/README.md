# Course-Management-System

This is the simple Course Management System built with Java.


## Database
-> MySQL

## Features
1. Admin
  i)CRUD operation of course
  ii)CRUD operation of modules
  iii)CRUD operation of teachers and students
  
2. Teacher
  i)View student detail of given module
  ii)Mark student 

3. Student
  i)View selected course and modules
  ii)View Teacher Details
