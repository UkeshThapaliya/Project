package com.View;

public class Gui {
    public Gui(){new Login();}

}
